/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Remover;

import Gameplay.Ball;
import Gameplay.Block;
import Gameplay.Game;
/**
 * A class that implements HitListener to remove blocks from the game upon collision with a ball.
 * Also removes itself as a listener from the block upon removal.
 */
public class BlockRemover implements HitListener {
    private Game game;
    private Counter remainingBlocks;
    /**
     * Constructs a BlockRemover object with the specified game and counter for remaining blocks.
     *
     * @param game the game instance from which blocks are removed
     * @param remainingBlocks the counter for tracking the number of remaining blocks
     */
    public BlockRemover(Game game, Counter remainingBlocks) {
        this.game = game;
        this.remainingBlocks = remainingBlocks;
    }
    // Blocks that are hit should be removed
    // from the game. Remember to remove this listener from the block
    // that is being removed from the game.
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        beingHit.removeHitListener(this);
        beingHit.removeFromGame(game);
        this.remainingBlocks.decrease(1);
    }
}
