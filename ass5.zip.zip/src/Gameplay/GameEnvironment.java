/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Gameplay;
import geometry.Line;
import java.util.LinkedList;
import java.util.List;

/**
 * Represents the game environment that manages collidable objects.
 * Keeps track of all collidables in a list.
 */
public class GameEnvironment {
    private final java.util.List<Collidable> collidables;
    private List<Block> frames;
    /**
     * Constructs a new GameEnvironment with an empty list of collidables.
     */
    public GameEnvironment() {
        this.collidables = new LinkedList<>();
        this.frames = new LinkedList<>();
    }
    /**
     * Adds a collidable object to the game environment.
     *
     * @param c the collidable object to add
     */
    public void addCollidable(Collidable c) {
        this.collidables.add(c);
    }

    /**
     * remove the collidable from the game.
     * @param c the collidable that we want to delete.
     */
    public void removeCollidable(Collidable c) {
        this.collidables.remove(c);
    }
    /**
    * Assume an object moving from line.start() to line.end().
    * If this object will not collide with any of the collidables
    * in this collection, return null. Else, return the information
    * about the closest collision that is going to occur.
    * @param trajectory the line that we are checking.
    * @return The information about the closest collision.
    */
    public CollisionInfo getClosestCollision(Line trajectory) {
        java.util.List<CollisionInfo> p = new LinkedList<>();
        for (Collidable c : collidables) {
            if (trajectory.closestIntersectionToStartOfLine(c.getCollisionRectangle()) != null) {
                CollisionInfo info = new CollisionInfo(
                        trajectory.closestIntersectionToStartOfLine(c.getCollisionRectangle()), c);
                p.add(info);
            }
        }
        if (p.isEmpty()) {
            return null;
        }
        CollisionInfo info = p.get(0);
        double distance = trajectory.getStart().distance(info.collisionPoint());
        for (CollisionInfo p2 : p) {
            double check = trajectory.getStart().distance(p2.collisionPoint());
            if (check < distance) {
                info = p2;
                distance = check;
            }
        }
        return info;
    }
    /**
     * Sets the list of frames for this object.
     *
     * @param frames the list of frames to set
     */
    public void setFrames(List<Block> frames) {
        this.frames = frames;
    }
    /**
     * Returns the list of frames associated with this object.
     *
     * @return the list of frames
     */
    public List<Block> getFrames() {
        return this.frames;
    }

}