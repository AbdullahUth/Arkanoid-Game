/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Gameplay;
import biuoop.DrawSurface;
import geometry.Line;
import geometry.Point;
import geometry.Rectangle;
import java.util.ArrayList;
import java.util.List;
import Remover.HitListener;
import Remover.HitNotifier;
import java.awt.Color;
/**
 * A Block class that implements Collidable and Sprite interfaces.
 * Blocks can be collided by balls.
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private final Color color;
    private final Rectangle rect;
    private final List<HitListener> hitListeners;

    /**
     * Constructs a Block with a specified rectangle and color.
     *
     * @param rect the rectangle defining the block's boundaries.
     * @param color the color of the block.
     */
    public Block(Rectangle rect, Color color) {
        this.rect = rect;
        this.color = color;
        this.hitListeners = new ArrayList<>();

    }
    @Override
    public Rectangle getCollisionRectangle() {
        return this.rect; }
    @Override
    // Notify the object that we collided with it at collisionPoint with
    // a given velocity.
    // The return is the new velocity expected after the hit (based on
    // the force the object inflicted on us).
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        double dx = currentVelocity.getdx(), dy = currentVelocity.getdy();
        Velocity vel = new Velocity(-dx, -dy);
        Line[] lines = getCollisionRectangle().makelines();
        int flag = -1, k = 0;
      for (int i = 0; i < lines.length; i++) {
            if (lines[i].isonline(collisionPoint)) {
                for (; k < 4; k++) {
                    if (k == i) {
                        continue;
                    }
                    if (lines[k].isonline(collisionPoint)) {
                        vel = new Velocity(-dx, -dy);
                        flag = 1;
                    }
                }
                if (flag == -1) {
                    if (lines[i].findslope() == 0) {
                        vel = new Velocity(dx, -dy);
                    } else if (Double.isInfinite(lines[i].findslope())) {
                        vel = new Velocity(-dx, dy);
                    } else {
                        if (!checkFrame(hitter)) {
                            if (!ballColorMatch(hitter)) {
                                this.notifyHit(hitter);
                            }
                        }
                        return vel;
                    }
                } else {
                    break;
                }

            }
        }
      if (!checkFrame(hitter)) {
          if (!ballColorMatch(hitter)) {
              this.notifyHit(hitter);
          }
      }
        return vel;
    }
    /**
     * Draws the block on the given DrawSurface.
     * @param d the DrawSurface on which to draw the block.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(Color.black);
        d.drawRectangle((int) this.getCollisionRectangle().getUpperLeft().getX(),
                (int) this.getCollisionRectangle().getUpperLeft().getY(),
                (int) this.getCollisionRectangle().getWidth(),
                (int) this.getCollisionRectangle().getHeight());

        // Set color to the ball's color and fill the ball's rectangle
        d.setColor(this.color);
        d.fillRectangle((int) this.getCollisionRectangle().getUpperLeft().getX(),
                (int) this.getCollisionRectangle().getUpperLeft().getY(),
                (int) this.getCollisionRectangle().getWidth(),
                (int) this.getCollisionRectangle().getHeight());
    }
    /**
     * Performs actions when time passes.
     * currently does nothing.
     */
    @Override
    public void timePassed() {

    }
    /**
     * Adds the block to the given game and to the sprites.
     * @param g the game to which the block is added
     */
    @Override
    public void addToGame(Game g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

    /**
     * checks if they are the same color.
     * @param ball the ball we need to compare to the block.
     * @return true if they are the same color. false otherwise.
     */
    public Boolean ballColorMatch(Ball ball) {
        return ball.getColor() == this.color;
    }
    /**
     * removes the block from the game.
     * @param game the game that we remove the block from.
     */
    public void removeFromGame(Game game) {
        game.removeCollidable(this);
        game.removeSprite(this);
    }
    private void notifyHit(Ball hitter) {
    // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<>(this.hitListeners);
    // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
        hitter.setColor(this.color);
    }
    @Override
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    @Override
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }

    /**
     * checks if is it a frame.
     * @param ball to get the frames from the environment.
     * @return true if the block is the frame, false otherwise.
     */
    public Boolean checkFrame(Ball ball) {
        List<Block> frame = ball.getGame().getFrames();
        for (Block b : frame) {
            if (b.equals(this)) {
                return true;
            }
        }
        return false;
    }


}
