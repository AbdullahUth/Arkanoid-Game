import Gameplay.Game;

/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
public class Ass3Game {
    /**
     * The Ass3Game class contains the main method to start and run the game.
     * its goal is to initialize the game.
     * @param args the command line arguments (not used).
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
