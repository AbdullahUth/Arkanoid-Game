/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Remover;

import Gameplay.Ball;
import Gameplay.Block;
/**
 * Interface for objects that listen to hit events between blocks and balls in a game.
 */
public interface HitListener {
    /**
     * This method is called whenever the beingHit object is hit by a ball.
     *
     * @param beingHit the block that was hit by the ball
     * @param hitter the ball that hit the block
     */
    void hitEvent(Block beingHit, Ball hitter);

}
