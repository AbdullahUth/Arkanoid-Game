/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Remover;
import Gameplay.Ball;
import Gameplay.Block;
/**
 * A class that implements HitListener to track and update the score based on ball-block collisions.
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;
    private Boolean oneHundred;
    /**
     * Constructs a ScoreTrackingListener with an initial score counter.
     *
     * @param scoreCounter the counter for tracking the score
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
        this.oneHundred = false;
    }
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
       this.currentScore.increase(5);
       if (oneHundred) {
           this.currentScore.increase(100);
       }
    }
    /**
     * Sets the oneHundred flag to true, allowing an additional 100 points to be added upon hit events.
     */
   public void setToOneHundred() {
        this.oneHundred = true;
   }
    /**
     * Returns the current score value.
     *
     * @return the current score value
     */
   public int getV() {
        return this.currentScore.getValue();
   }
}
