/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Remover;
import Gameplay.Ball;
import Gameplay.Block;
import Gameplay.Game;
/**
 * A class that implements HitListener to remove balls from the game upon collision with a block.
 */
public class BallRemover implements HitListener {
    private Game game;
    private Counter counterBalls;
    /**
     * Constructs a BallRemover object with the specified game and counter for balls.
     *
     * @param game the game instance from which balls are removed
     * @param counter the counter for tracking the number of balls
     */
    public BallRemover(Game game, Counter counter) {
        this.game = game;
        this.counterBalls = counter;
    }
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        this.counterBalls.decrease(1);
        hitter.removeFromGame(this.game);
        this.game.removeSprite(hitter);
    }
}
