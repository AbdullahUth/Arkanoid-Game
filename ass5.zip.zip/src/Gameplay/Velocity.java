package Gameplay;

import geometry.Point;

/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */

public class Velocity {
    private double dx;
    private double dy;
    /**
     * Constructs a velocity with given dx and dy components.
     * @param dx the change in x (horizontal) coordinate
     * @param dy the change in y (vertical) coordinate
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
    /**
     * Applies the velocity to a point.
     * @param p the point to apply the velocity to
     * @return a new point after applying the velocity
     */
    public Point applyToPoint(Point p) {
        double nx = p.getX() +  dx;
        double ny = p.getY() + dy;
        return new Point(nx, ny);
    }
    /**
     * Gets the change in x coordinate.
     * @return the dx component of the velocity
     */
    public double getdx() {
        return this.dx;
    }
    /**
     * Gets the change in y coordinate.
     * @return the dy component of the velocity
     */
    public double getdy() {
        return this.dy;
    }
    /**
     * Calculates the velocity vector based on an angle and speed.
     * @param angle the angle of the velocity vector in degrees
     * @param speed the speed of the velocity
     * @return a new velocity object representing the velocity vector
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double radians = Math.toRadians(angle - 90);
        double dx = speed * Math.cos(radians);
        double dy = speed * Math.sin(radians);
        return new Velocity(dx, dy);
    }

}


