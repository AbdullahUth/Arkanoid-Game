/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Remover;
/**
 * A simple counter class that allows for incrementing, decrementing, and retrieving the current count.
 */
public class Counter {
    private int count;
    /**
     * Constructs a counter with an initial value.
     *
     * @param counter the initial value of the counter
     */
    public Counter(int counter) {
        this.count = counter;
    }
    /**
     * Increases the counter by the specified number.
     *
     * @param number the number to add to the current count
     */
    public void increase(int number) {
        count += number;
    }
    /**
     * Decreases the counter by the specified number.
     *
     * @param number the number to subtract from the current count
     */
    public void decrease(int number) {
        count -= number;
    }
    /**
     * Returns the current value of the counter.
     *
     * @return the current count value
     */
    public int getValue() {
        return this.count;
    }

}
