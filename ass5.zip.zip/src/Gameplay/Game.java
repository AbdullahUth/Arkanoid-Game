/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Gameplay;
import biuoop.GUI;
import biuoop.DrawSurface;
import biuoop.Sleeper;
import geometry.Point;
import geometry.Rectangle;
import java.awt.Color;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import Remover.BlockRemover;
import Remover.BallRemover;
import Remover.Counter;
import Remover.ScoreIndicator;
/**
 * Represents the game.
 * Manages initialization, adding of collidables and sprites, and running the game loop.
 */
public class Game {
    private final GUI g;
    private final SpriteCollection sprites;
    private final GameEnvironment environment;
    private final Sleeper sleeper;
    private final Counter counterBlocks;
    private final Counter counterBalls;
    private final ScoreIndicator score;
    private final List<Block> frame;

    /**
     * Constructs a new Game instance.
     * Initializes the GUI, sprite collection, game environment, and sleeper.
     */
    public Game() {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
         this.g = new GUI("Game", 800, 600);
         sleeper = new Sleeper();
         counterBlocks = new Counter(50);
         counterBalls  = new Counter(3);
         this.score = new ScoreIndicator();
         this.frame = new LinkedList<>();
    }
    /**
     * Adds a collidable object to the game environment.
     * @param c the collidable object to add.
     */
    public void addCollidable(Collidable c) {
        environment.addCollidable(c);
    }
    /**
     * Adds a sprite object to the game.
     * @param s the sprite object to add.
     */
    public void addSprite(Sprite s) {
        sprites.addSprite(s);
    }

    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle).
     * and add them to the game.
     */
    public void initialize() {
        Ball ball1 = new Ball(new Point(200, 200), 6, Color.white, environment);
        Ball ball2 = new Ball(new Point(210, 260), 6, Color.black, environment);
        Ball ball3 = new Ball(new Point(220, 270), 6, Color.red, environment);
        Block backscereen  = new Block(new Rectangle(new Point(0, 0), 800, 600), Color.blue);
        backscereen.addToGame(this);
        ball1.setVelocity(3, 5);
        ball2.setVelocity(3, 5);
        ball3.setVelocity(3, 5);
        ball1.addToGame(this);
        ball2.addToGame(this);
        ball3.addToGame(this);
        Random rand = new Random();
        Block b1 = new Block(new Rectangle(new Point(0, 0), 20, 580), Color.gray);
        b1.addToGame(this);
        frame.add(b1);
        Block b2 = new Block(new Rectangle(new Point(0, 580), 800, 20), Color.gray);
        b2.addToGame(this);
        frame.add(b2);
        Block b3 = new Block(new Rectangle(new Point(0, 0), 800, 20), Color.gray);
        b3.addToGame(this);
        frame.add(b3);
        Block b4 = new Block(new Rectangle(new Point(780, 0), 20, 580), Color.gray);
        b4.addToGame(this);
        frame.add(b4);
        this.environment.setFrames(frame);
        ball1.frame(780, 580);
        ball2.frame(780, 580);
        ball3.frame(780, 580);
        Rectangle pad = new Rectangle(new Point(400, 560), 100, 20);
        Paddle paddle = new Paddle(pad, Color.green, g, 20, 780);
        BlockRemover b = new BlockRemover(this, counterBlocks);
        BallRemover ballRemover = new BallRemover(this, counterBalls);
        ball1.addHitListener(ballRemover);
        ball2.addHitListener(ballRemover);
        ball3.addHitListener(ballRemover);
        paddle.addToGame(this);
        for (int i = 0; i < 5; i++) {
            int x1 = rand.nextInt(255);
            int x2 = rand.nextInt(255);
            int x3 = rand.nextInt(255);
            Color color = new Color(x1, x2, x3);
            for (int j = i; j < 12; j++) {
                Point upperleft = new Point(170 + 50 * j, 100 + 25 * i);
                Rectangle rectangle = new Rectangle(upperleft, 60, 25);
                Block block = new Block(rectangle, color);
                block.addToGame(this);
                block.addHitListener(b);
                block.addHitListener(score.getScore());
            }
        }
        this.addSprite(score);
    }
    /**
    * Runs the game's animation loop.
    */
    public void run() {
        //...
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = g.getDrawSurface();
            this.sprites.drawAllOn(d);
            g.show(d);
            this.sprites.notifyAllTimePassed();
            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
            if (this.counterBlocks.getValue() == 0 || this.counterBalls.getValue() == 0) {
                if (this.counterBlocks.getValue() == 0) {
                    this.score.getScore().setToOneHundred();
                }
                this.g.close();
                return;
            }
        }
    }
    /**
     * Removes a collidable object from the environment.
     *
     * @param c the collidable object to be removed
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }

    /**
     * Removes a sprite from the collection of sprites.
     *
     * @param s the sprite to be removed
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }

}
