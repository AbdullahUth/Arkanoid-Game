/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Gameplay;
import biuoop.DrawSurface;
/**
 * Interface for objects that can be drawn on a DrawSurface and updated over time in a game.
 */
public interface Sprite {
    /**
     * Draws the sprite on the given DrawSurface.
     *
     * @param d the DrawSurface on which to draw the sprite
     */
    void drawOn(DrawSurface d);
    /**
     * Notifies the sprite that time has passed, allowing it to update its state.
     */
    void timePassed();
    /**
     * Adds the sprite to the specified game.
     *
     * @param g the game to which the sprite is added
     */
    void  addToGame(Game g);
}
