/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Gameplay;
import geometry.Point;

/**
 * It holds information about a collision, the collision point and the object that got hit by the ball.
 */
public class CollisionInfo {
    private final Point p;
    private final Collidable object;

    /**
     *  Constructs a CollisionInfo object with a specified collision point and collidable object.
     * @param p The collision point.
     * @param object The object (the block).
     */
    public CollisionInfo(Point p, Collidable object) {
        this.p = p;
        this.object = object;
    }

    /**
     *  the point at which the collision occurs.
     * @return  the point at which the collision occurs.
     */
    public Point collisionPoint() {
        return this.p; }

    /**
     * the collidable object involved in the collision.
     * @return the block that hit the ball.
     */
    public Collidable collisionObject() {
        return this.object; }

}
