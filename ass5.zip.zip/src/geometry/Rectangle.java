/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package geometry;
import java.util.LinkedList;
import java.util.List;

/**
 * Represents a rectangle in a 2D space defined by its upper-left corner, width, and height.
 */
public class Rectangle {
    private final Point upperLeft;
    private final double width;
    private final double height;

    /**
     * Constructs a new rectangle with the specified upper-left corner, width, and height.
     * @param upperLeft the upper-left corner of the rectangle.
     * @param width the width of the rectangle.
     * @param height the height of the rectangle.
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
    }

    /**
     * Returns a list of intersection points of this rectangle with a given line.
     * @param line the line to intersect with this rectangle.
     * @return a list of intersection points, or null if there are no intersections.
     */
    public List<Point> intersectionPoints(Line line) {
        List<Point> intersectionPoints = new LinkedList<>();
        Line[] lines = makelines();
        for (Line rectLine : lines) {
            Point intersection = rectLine.intersectionWith(line);
            if (intersection != null) {
                intersectionPoints.add(intersection);
            }
        }
        if (intersectionPoints.isEmpty()) {
            return null;
        }
        return intersectionPoints;
    }

    /**
     * Creates and returns an array of the four lines representing this rectangle.
     * @return an array of lines representing the edges of this rectangle.
     */
    public Line[] makelines() {
        Line[] lines = new Line[4];
        Point upperRight = new Point(this.upperLeft.getX() + width, this.upperLeft.getY());
        Point bottomLeft = new Point(this.upperLeft.getX(), this.upperLeft.getY() + height);
        Point bottomRight = new Point(upperRight.getX(), bottomLeft.getY());

        // Create the lines of the rectangle
        Line topLine = new Line(this.upperLeft, upperRight);
        Line leftLine = new Line(this.upperLeft, bottomLeft);
        Line rightLine = new Line(upperRight, bottomRight);
        Line bottomLine = new Line(bottomLeft, bottomRight);

        lines[0] = topLine;
        lines[1] = bottomLine;
        lines[2] = leftLine;
        lines[3] = rightLine;

        return lines;
    }

    /**
     * Returns the width of this rectangle.
     * @return the width of this rectangle.
     */
    public double getWidth() {
        return this.width;
    }

    /**
     * Returns the height of this rectangle.
     * @return the height of this rectangle.
     */
    public double getHeight() {
        return this.height;
    }

    /**
     * Returns the upper-left corner of this rectangle.
     * @return the upper-left corner of this rectangle.
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }
}
