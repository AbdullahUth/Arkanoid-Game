/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package geometry;
/**
 * Represents a line.
 */
public class Line {
    private double x1;
    private double y1;
    private double x2;
    private double y2;
    private final Point start;
    private final Point end;
    /**
     * Constructs a line segment from two points.
     * @param start the starting point of the line.
     * @param end  the ending point of the line.
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }
    /**
     * Constructs a line segment from coordinates.
     * @param x1 the x-coordinate of the starting point.
     * @param y1 the y-coordinate of the starting point.
     * @param x2 the x-coordinate of the ending point.
     * @param y2 the y-coordinate of the ending point.
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
    }
    /**
     * Calculates the length of the line segment.
     * @return the length of the line segment.
     */
    public double length() {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
    /**
     * Calculates the midpoint of the line segment.
     * @return the midpoint of the line segment.
     */
    public Point middle() {
        return new Point((this.start.getX() + this.end.getX()) / 2,
                (this.start.getY() + this.end.getY()) / 2);
    }
    /**
     * Returns the endpoint of the line segment.
     * @return the endpoint of the line segment.
     */
    public Point end() {
        return new Point(end.getX(), end.getY());
    }
    /**
     * @return the start point of the line segment
     */
    public Point getStart() {
        return this.start; }
    /**
     * Checks if this line segment intersects with another line segment.
     * @param other the other line segment to check intersection with.
     * @return true if the line segments intersect, false otherwise.
     */
    public boolean isIntersecting(Line other) {
        return this.intersectionWith(other) != null;
    }
    /**
     * Checks if this line segment intersects with two other line segments.
     * @param other1 the first other line segment to check intersection with.
     * @param other2 the second other line segment to check intersection with.
     * @return true if this line segment intersects with both other line segments, else it returns false.
     */
    public boolean isIntersecting(Line other1, Line other2) {
        return this.isIntersecting(other1) && this.isIntersecting(other2);
    }
    /**
     * Finds the intersection point of this line segment with another line segment.
     * @param other the other line segment to find intersection with.
     * @return the intersection point if exists, null otherwise.
     */
    public Point intersectionWith(Line other) {
        //if the same line.
        if (equals(other)) {
            return null;
        }
        // if the one line starts with the end of the other.
        if (start.equals(other.end)) {
            return start;
        } else if (end.equals(other.start)) {
            // if one line ends with the starts of the other.
            return end;
        }
        //if they start or end at the same point.
        if (this.ifstart(other) != null) {
            return this.ifstart(other);
        }
        //if the same slope
        if (this.findslope() == other.findslope() || (this.isvertical() && other.isvertical())) {
            //if a line resumes the other
            if (start.equals(other.end)) {

                return start;
            } else if (end.equals(other.start)) {
                return end;
            }

            //if the start/end point is in the other line
            if (isonline(other.start) || isonline(other.end)) {
                return isonline(other.start) || isonline(other.end) ? other.start : other.end;
            } else {
                return null;
            }

        }
        Point intersection;
        if (this.isvertical()) {
            double x = start.getX();
            double m = other.findslope();
            Point temp = other.start;
            double y = (x - temp.getX()) * m + temp.getY();
            intersection = new Point(x, y);

        } else if (other.isvertical()) {
            double x = other.start.getX();
            double m = this.findslope();
            Point temp = this.start;
            double y = (x - temp.getX()) * m + temp.getY();
            intersection = new Point(x, y);
        } else {
            double m1 = this.findslope();
            double m2 = other.findslope();
            double b1 = this.findb(m1);
            double b2 = other.findb(m2);
            double ineX = (b2 - b1) / (m1 - m2);
            double ineY = m1 * ineX + b1;
            intersection = new Point(ineX, ineY);
        }
        if (this.isonline(intersection) && other.isonline(intersection)) {
            return intersection;
        }
        return null;
    }

    /**
     * finds the line slope.
     * @return the slope of the line.
     */
    public double findslope() {
        double s1 = this.end.getY() - this.start.getY();
        double s2 = this.end.getX() - this.start.getX();
        return s1 / s2;
    }

    /**
     * checks if the line is vertical.
     * @return true if it is vertical, false otherwise.
     */
    public boolean isvertical() {
        return this.start.getX() == this.end.getX();
    }

    /**
     * Checks the two lines are the same.
     * @param other the other line we are checking with.
     * @return true if they are the same line, false otherwise.
     */
    public boolean equals(Line other) {
        if (this.start == other.start && this.end == other.end) {
            return true;
        }
        return this.start == other.end && this.end == other.start;
    }
    /**
     * checks if the line is horizontal.
     * @return true if it is horizontal, false otherwise.
     */
    public boolean ishorizon() {
        return this.start.getY() == this.end.getY();
    }

    /**
     * Finds a point on this line segment that is very close to the start of another line segment.
     * @param other the other line segment to compare with
     * @return a point on this line segment that is close to the start of the other line segment
     * null if not close enough
     */
    public Point ifstart(Line other) {
        double epsilon = 0.1;
        if (Math.abs(this.start.getX() - other.start.getX()) <= epsilon
                && Math.abs(this.start.getY() - other.start.getY()) <= epsilon) {
            return this.start;
        }
        if (Math.abs(this.start.getX() - other.end.getX()) <= epsilon
                && Math.abs(this.start.getY() - other.end.getY()) <= epsilon) {
            return this.start;
        }
        if (Math.abs(this.end.getX() - other.start.getX()) <= epsilon
                && Math.abs(this.end.getY() - other.start.getY()) <= epsilon) {
            return this.end;
        }
        if (Math.abs(this.end.getX() - other.end.getX()) <= epsilon
                && Math.abs(this.end.getY() - other.end.getY()) <= epsilon) {
            return this.end;
        }
        return null;
    }
    /**
     * Finds b in y = mx + b.
     * @param m the slope of the line
     * @return the y-intercept of the line
     */
    public double findb(double m) {
        return this.start.getY() - (this.start.getX() * m);
    }
    /**
     * Checks if a given point lies on this line segment.
     * @param p the point to check.
     * @return true if the point lies on this line segment, false otherwise.
     */
    public boolean isonline(Point p) {
        if (p == null) {
            return false;
        }
        if (p.getX() >= this.start.getX() && p.getX() <= this.end.getX()) {
            if (p.getY() >= this.start.getY() && p.getY() <= this.end.getY()) {
                return true;
            }
            if (p.getY() <= this.start.getY() && p.getY() >= this.end.getY()) {
                return true;
            }
        }
        if (p.getX() <= this.start.getX() && p.getX() >= this.end.getX()) {
            if (p.getY() <= this.start.getY() && p.getY() >= this.end.getY()) {
                return true;
            }
            return p.getY() >= this.start.getY() && p.getY() <= this.end.getY();
        }
        return false;
    }
    /** If this line does not intersect with the rectangle, return null.
     * Otherwise, return the closest intersection point to the
     * start of the line.
     * @param rect we are checking with.
     * @return the closest intersection point to the start of the line, if there are not then null
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        Line line = new Line(this.start, this.end);
        java.util.List<Point> points;
        points = rect.intersectionPoints(line);
        //if there is no collidables / intesect ; return null
        if (points == null) {
            return null;
        }
        //if the list is not empty, we want to cheack the closet one
        Point p = points.get(0);
        double min = start.distance(p);
        for (Point p1 : points) {
            if (min > start.distance(p1)) {
                p = p1;
                min = start.distance(p1);
            }
        }
        return p;
    }
}