package Gameplay;

import geometry.Point;
import geometry.Rectangle;

/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */

public interface Collidable {
    /**
     * Returns the collision shape (rectangle) of the object.
     * @return the collision rectangle representing the shape of the collidable object
     */
    Rectangle getCollisionRectangle();
    /**
     * Notifies the object that it has been hit by a ball at a specific collision point
     * with a given velocity.
     * @param hitter the ball object that hit this collidable
     * @param collisionPoint the point where the collision occurred
     * @param currentVelocity the current velocity of the ball when it hit this collidable
     * @return the new velocity of the ball after the collision
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}
