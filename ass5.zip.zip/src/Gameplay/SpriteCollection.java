/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Gameplay;
import biuoop.DrawSurface;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
/**
 * A collection of sprites that manages their behavior and rendering.
 */
public class SpriteCollection {
    private final LinkedList<Sprite> list;

    /**
     * Constructor that starts a sprite collection list.
     */
    public SpriteCollection() {
        this.list = new LinkedList<>();
    }

    /**
     * adds the sprite to the collection.
     * @param s the sprite we want to add.
     */
    public void addSprite(Sprite s) {
        this.list.add(s);
    }

    /**
     * call timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        // Using a copy of the list to avoid ConcurrentModificationException
        List<Sprite> spritesCopy = new ArrayList<>(list);
        for (Sprite sprite : spritesCopy) {
            sprite.timePassed();
        }
    }

    /**
     * call drawOn(d) on all sprites.
     * @param d the DrawSurface to draw on.
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite l : list) {
            l.drawOn(d);
        }
    }

    /**
     * removes the sprite from the game.
     * @param s the sprite we need to delete.
     */
    public void removeSprite(Sprite s) {
        this.list.remove(s);
    }
}
