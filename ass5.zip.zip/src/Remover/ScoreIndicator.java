/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Remover;
import Gameplay.Game;
import Gameplay.Sprite;
import biuoop.DrawSurface;
import java.awt.Color;
/**
 * A class that implements Sprite to display the current score on a game's DrawSurface.
 */
public class ScoreIndicator implements Sprite {
    private ScoreTrackingListener score;
    private Counter count;
    /**
     * Constructs a ScoreIndicator with an initial score of 0.
     */
    public ScoreIndicator() {
        count = new Counter(0);
        this.score = new ScoreTrackingListener(count);
    }
    /**
     * Returns the ScoreTrackingListener associated with this ScoreIndicator.
     *
     * @return the ScoreTrackingListener object that tracks the score
     */
    public ScoreTrackingListener getScore() {
        return this.score;
    }
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(Color.black);
        d.drawText(380, 15, "score: " + this.getScore().getV(), 15);
    }

    @Override
    public void timePassed() {

    }

    @Override
    public void addToGame(Game g) {

    }
}
