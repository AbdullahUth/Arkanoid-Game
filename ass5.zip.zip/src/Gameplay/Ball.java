/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Gameplay;
import biuoop.DrawSurface;
import geometry.Line;
import geometry.Point;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import Remover.HitListener;
import Remover.HitNotifier;

/**
 * The Ball class provides methods to get the ball's properties
 * draw it on a surface, set its velocity
 * and move it within specified boundaries.
 */
public class Ball implements Sprite, HitNotifier {
    private final int r;
    private geometry.Point center;
    private java.awt.Color color;
    private Velocity velocity;
    private double width;
    private double height;
    private final GameEnvironment game;
    private final List<HitListener> hitListeners;
    /**
     * Constructs a ball with specified center, radius, and color.
     * @param center the center point of the ball.
     * @param r the radius of the ball.
     * @param color the color of the ball.
     * @param game the game environment in which the ball exists.
     */
    public Ball(geometry.Point center, int r, java.awt.Color color, GameEnvironment game) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.game = game;
        this.hitListeners = new ArrayList<>();
    }

    /**
     * @return the x coordinate of the ball center.
     */
    public double getX() {
        return this.center.getX(); }
    /**
     * @return the y-coordinate of the center point.
     */
    public double getY() {
        return this.center.getY();
    }

    /**
     * @return the radius (size) of the ball.
     */
    public int getSize() {
        return this.r;
    }
    /**
     * Returns the color of the ball.
     *
     * @return the color of the ball
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * Returns the center point of the ball.
     *
     * @return the center point of the ball
     */
    public geometry.Point getCenter() {
        return this.center;
    }

    /**
     * Returns the game environment in which the ball exists.
     *
     * @return the game environment of the ball
     */
    public GameEnvironment getGame() {
        return this.game;
    }

    /**
     * Draws the ball on the given surface.
     * @param surface the surface to draw the ball on.
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillCircle((int) center.getX(), (int) center.getY(), r);
    }
    /**
     * Sets the velocity of the ball.
     * @param v the new velocity to be set
     */
    public void setVelocity(Velocity v) {
        this.velocity = v;
    }
    /**
     * Sets the velocity of the ball using the specified x and y components.
     * @param dx the x component of the new velocity.
     * @param dy the y component of the new velocity.
     */
    public void setVelocity(double dx, double dy) {
        this.velocity = new Velocity(dx, dy);
    }
    /**
     * @return the current velocity of the ball.
     */
    public Velocity getVelocity() {
        return this.velocity;
    }

    /**
     * @return the width of the game environment.
     */
    public double getWidth() {
        return this.width; }

    /**
     * @return the height of the game environment.
     */
    public double getHeight() {
        return this.height;  }
    /**
     * Sets the frame boundaries for the ball's movement.
     * @param width the width of the frame.
     * @param height the height of the frame
     */
    public void frame(double width, double height) {
        this.width = width;
        this.height = height;
    }
    /**
     * Moves the object one step based on its velocity.
     * If the object encounters a collision with a block it updates its velocity accordingly.
     * Else, it checks for frame collisions.
     * If yes, it changes the velocity.
     * Finally, it updates the object's position.
     */
    public void moveOneStep() {
        geometry.Point end = this.velocity.applyToPoint(this.center);
        Line trajectory = new Line(this.center, end);
        CollisionInfo c = this.game.getClosestCollision(trajectory);
        if (c != null) {
            Point hit = c.collisionPoint();
            Collidable c2 = c.collisionObject();
            velocity = c2.hit(this, hit, this.velocity);
        } else {
            double nextx = this.getVelocity().applyToPoint(center).getX();
            double nexty = this.getVelocity().applyToPoint(center).getY();
            if (nextx + this.getSize() >= this.getWidth() || nextx <= 0) {
                this.velocity = new Velocity(-this.velocity.getdx(), this.velocity.getdy());
            }
            if (nexty + this.getSize() >= this.getHeight() || nexty <= 0) {
                this.velocity = new Velocity(this.velocity.getdx(), -this.velocity.getdy());
                if (checkFrame()) {
                    notifyHit();
                    return;
                }
            }
            this.center = this.getVelocity().applyToPoint(this.center);
        }

    }
    /**
     * Adds this object to the given game.
     *
     * @param g the game to which this object is added
     */
    @Override
    public void addToGame(Game g) {
        g.addSprite(this);
    }

    /**
     * It calls the moveOneStep method to move the ball.
     */
    @Override
    public void timePassed() {
        moveOneStep();
    }

    /**
     * sets a new color to the ball.
     * @param c is the color we need to change to.
     */
    public void setColor(Color c) {
        this.color = c;
    }

    /**
     * removes the ball from the game.
     * @param game the game that we remove the ball from.
     */
    public void removeFromGame(Game game) {
        game.removeSprite(this);
    }

    @Override
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    @Override
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }
    private void notifyHit() {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(null, this);
        }
    }

    /**
     * checks if the frame is the death region.
     * @return true if it is the death region, false otherwise.
     */
    public Boolean checkFrame() {
       if (this.center.getX() > 0 && this.center.getX() < 780) {
           return this.center.getY() > 0 && this.center.getY() < 580;
       }
       return false;
    }

}