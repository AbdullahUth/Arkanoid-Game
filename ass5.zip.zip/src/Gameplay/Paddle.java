/**
 * ID: 324992593
 * Name: Abullah Uthman.
 * @version 19.0.2
 * @since 13-7-2024
 */
package Gameplay;
import biuoop.GUI;
import java.awt.Color;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import geometry.Line;
import geometry.Point;
import geometry.Rectangle;

/**
 * The Paddle class represents a paddle in a game. It implements both the Sprite and Collidable interfaces.
 * The paddle can move left and right based on the user input and can collide with other objects(blocks).
 */
public class Paddle implements Sprite, Collidable {
    private final biuoop.KeyboardSensor keyboard;
    private Rectangle rect;
    private final Color color;
    private final GUI g;
    private final double frame1;
    private final double frame2;
    /**
     * Constructs a new Paddle with the specified parameters.
     * @param rect the rectangle representing the paddle's shape and position.
     * @param color the color of the paddle.
     * @param g the GUI environment where the paddle operates.
     * @param frame1 the left frame boundary for the paddle's movement.
     * @param frame2 the right frame boundary for the paddle's movement.
     */
    public Paddle(Rectangle rect, Color color, GUI g, double frame1, double frame2) {
        this.rect = rect;
        this.color = color;
        this.g = g;
        keyboard = g.getKeyboardSensor();
        this.frame1 = frame1;
        this.frame2 = frame2;
    }
    /**
     * Moves the paddle left by 5 if possible.
     */
    public void moveLeft() {
        if (this.getCollisionRectangle().getUpperLeft().getX()  - 5 >= frame1) {
            Point p = new Point(this.getCollisionRectangle().getUpperLeft().getX() - 5,
                    this.getCollisionRectangle().getUpperLeft().getY());
            this.rect = new Rectangle(p, rect.getWidth(), rect.getHeight());
        }
    }
    /**
     * Moves the paddle right by 5 possible.
     */
    public void moveRight() {
        double width = this.getCollisionRectangle().getWidth();
        if (this.getCollisionRectangle().getUpperLeft().getX() + width < frame2) {
            Point p = new Point(this.getCollisionRectangle().getUpperLeft().getX() + 5,
                    this.getCollisionRectangle().getUpperLeft().getY());
            this.rect = new Rectangle(p, rect.getWidth(), rect.getHeight());
        }
    }

    // Sprite
    @Override
    public void timePassed() {
        if (keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            moveLeft();
        } else if ((keyboard.isPressed(KeyboardSensor.RIGHT_KEY))) {
            moveRight();
        }

    }
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle((int) this.getCollisionRectangle().getUpperLeft().getX(),
                (int) this.getCollisionRectangle().getUpperLeft().getY(),
                (int) this.getCollisionRectangle().getWidth(), (int) this.getCollisionRectangle().getHeight());
    }
    /**
     * Returns the collision rectangle of the block.
     * @return the collision rectangle
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }
    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        double hitPoint = collisionPoint.getX();
        double dx = currentVelocity.getdx();
        double dy = currentVelocity.getdy();
        double firstX = rect.getUpperLeft().getX();
        double fiveSections = rect.getWidth() / 5;
        double ballSpeed = calculateSpeed(dx, dy);
        double x1 = fiveSections + firstX;
        double x2 = 2 * fiveSections + firstX;
        double x3 = 3 * fiveSections + firstX;
        double x4 = 4 * fiveSections + firstX;
        double x5 = 5 * fiveSections + firstX;

        if (this.getCollisionRectangle().getUpperLeft().getX() <= hitPoint && hitPoint <= x1) {
            return Velocity.fromAngleAndSpeed(300, ballSpeed);
        } else if (x1 <= hitPoint && hitPoint <= x2) {
            return Velocity.fromAngleAndSpeed(330, ballSpeed);
        } else if (x2 <= hitPoint && hitPoint <= x3) {
            return new Velocity(currentVelocity.getdx(), -currentVelocity.getdy());
        } else if (x3 <= hitPoint && hitPoint <= x4) {
            return Velocity.fromAngleAndSpeed(30, ballSpeed);
        } else if (x4 <= hitPoint && hitPoint <= x5) {
            return Velocity.fromAngleAndSpeed(60, ballSpeed);
        } else {
            Line[] lines = this.getCollisionRectangle().makelines();
            for (Line line : lines) {
                if (line.isonline(collisionPoint) && line.ishorizon()) {
                    currentVelocity = new Velocity(-currentVelocity.getdx(), currentVelocity.getdy());
                }
            }
        }
        return currentVelocity;


    }
    /**
     * Calculates the speed given the dx and dy components of a velocity.
     * @param dx the horizontal component of the velocity.
     * @param dy the vertical component of the velocity.
     * @return the speed magnitude.
     */
    public double calculateSpeed(double dx, double dy) {
        return Math.sqrt(dx * dx + dy * dy);
    }
    /**
     * Adds this paddle to the game.
     * @param g the Game to add this paddle to.
     */
    public void addToGame(Game g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

}